/*
Andrew Ingalls
ID: 2368574
Aingalls@chapman.edu
CPSC 350-01
PA4: Genetic Palindromes

Source Files:
ListNode.h
DblList.h
DNASeq.h
DNASeq.cpp
PalindromeFinder.h
PalindromeFinder.cpp
main.cpp
sample.txt

No compile/runtime errors

I went to the TLC to help me visualize what I needed to accomplish, more specifically 
how to check if the sequence was a palindrome using the for loops. I used chatGPT to help me debug 
a few errors because I got a lot of segmentation faults when trying to figure out when to use 
pointers and when not to. 

TO COMPILE:
g++ -o main *.cpp

TO RUN:
./main
Enter name of the input file: sample.txt
*/