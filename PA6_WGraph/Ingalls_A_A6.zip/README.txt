/*
Andrew Ingalls
ID: 2368574
Aingalls@chapman.edu
CPSC 350-01
PA6: Spanning The Gamut

Source Files:
WGraph.h
WGraph.cpp
FileProcessor.h
FileProcessor.cpp
main.cpp
Input.txt


No compile/runtime errors

For this assignment I went to the TLC and they helped me understand how to create the graph and adjacency matrix.
I was a little confused going into the project, but they helped me comprehend it and help generate my
computeMST function in the WGraph class because that was the most confusing. Other than that I only needed
help debugging because I kept on getting errors working with the arrays so I used ChatGPT to help debug only. 


TO COMPILE:
g++ -o main *.cpp

TO RUN:
./main Input.txt
*/