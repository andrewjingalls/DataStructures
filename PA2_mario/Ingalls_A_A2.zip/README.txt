/*
Andrew Ingalls
ID: 2368574
Aingalls@chapman.edu
CPSC 350-01
PA2: Not So Super Mario Bros.

Source Files:
Game.h
Game.cpp
GameParametersReader.h
GameParametersReader.cpp
GameParameters.txt
Level.h
Level.cpp
LevelElement.h
LevelElement.cpp
main.cpp
Mario.h
Mario.cpp
World.h
World.cpp


No compile/runtime errors

I went to the TLC to understand how to comprehend the project. There were a lot of moving 
parts and a lot of things to implement so I needed help wraping my head around it. They helped especially with 
initializing the levels with the correct elements and the play function in game because those were definitely the 
hardest parts for me. Pointers are especially a difficult concept for me so they helped explain how to correctly use them 
because I got plenty of segmentation faults. 

TO COMPILE:
g++ -o main *.cpp

TO RUN:
./main
Enter name of the input and output files
*/