/*
Andrew Ingalls
ID: 2368574
Aingalls@chapman.edu
CPSC 350-01
PA1: Robber Language Translation

Source Files:
Model.h 
Model.cpp
Translator.h 
Translator.cpp
FileProcessor.h 
FileProcessor.cpp
main.cpp

No compile/runtime errors

I went to the TLC for help with my translateEnglishSentence method
because I had trouble splitting the sentence into multiple words to be translated.
They also helped me think about the process of checking for vowels and punctuation.
I also used chatGPT to help debug my code and help solve errors that would pop up, 
as well as explaining the basics to writing HTML files. I also used the provided HTML 
tutorial website provided to help produce the webpage. 

TO COMPILE:
g++ -o main *.cpp

TO RUN:
./main inputFileName outputFileName
*/