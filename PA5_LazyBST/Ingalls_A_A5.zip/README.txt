/*
Andrew Ingalls
ID: 2368574
Aingalls@chapman.edu
CPSC 350-01
PA5: LazyBST

Source Files:
Database.h
Database.cpp
Student.h
Student.cpp
Faculty.h
Faculty.cpp
DblList.h
ListNode.h
LazyBST.h
TreeNode.h
main.cpp


No compile/runtime errors

I went to the TLC for a lot of help for my BST and help with the rebalancing of the trees.
I also used the internet and a few websites listed below for help understanding some of the concepts used in my code.
For example lambda expressions for being able to return each object in the tree similar to how we 
implemented the printTree function in BST class. I was also very stuck on how to 
print the students and faculty to the output file and I found a way to redirect cout to a file. 
I had to also go to the TLC to help me implement it because I sort of understood but had troubles with the syntax.
I used ChatGPT for general debugging and for some help when I kept getting syntax errors. 


TO COMPILE:
g++ -o main *.cpp

TO RUN:
./main
*/

REFERENCES:
https://www.geeksforgeeks.org/lambda-expression-in-c/
https://stackoverflow.com/questions/10150468/how-to-redirect-cin-and-cout-to-files